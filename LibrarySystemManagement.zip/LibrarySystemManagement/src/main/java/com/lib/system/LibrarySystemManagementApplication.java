package com.lib.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarySystemManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarySystemManagementApplication.class, args);
	}

}
